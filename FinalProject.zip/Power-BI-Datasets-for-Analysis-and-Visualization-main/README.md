# Power-BI-Datasets-for-Analysis-and-Visualization
This repository contains the used datasets used in our video tutorials for Business Intelligence Competition. This will be fruitful and productive for practicing the Desktop Application of BI
